namespace Demo_student_application {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demo_student_application.InputSchema", typeof(global::Demo_student_application.InputSchema))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demo_student_application.TypedProcedure_dbo+getstudentInformationResponse", typeof(global::Demo_student_application.TypedProcedure_dbo.getstudentInformationResponse))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demo_student_application.OutPutSchema", typeof(global::Demo_student_application.OutPutSchema))]
    public sealed class OutputMessegeTransform : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s2 s3 s0 s1"" version=""1.0"" xmlns:s2=""http://schemas.microsoft.com/BizTalk/2003/aggschema"" xmlns:ns0=""http://Demo_student_application.OutPutSchema"" xmlns:s3=""http://schemas.microsoft.com/Sql/2008/05/ProceduresResultSets/dbo/getstudentInformation"" xmlns:s1=""http://schemas.microsoft.com/Sql/2008/05/TypedProcedures/dbo"" xmlns:s0=""http://Demo_student_application.InputSchema"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s2:Root"" />
  </xsl:template>
  <xsl:template match=""/s2:Root"">
    <ns0:Output>
      <RegistrationID>
        <xsl:value-of select=""InputMessagePart_0/s0:StudentDetails/ReqID/text()"" />
      </RegistrationID>
      <Marks>
        <xsl:value-of select=""InputMessagePart_0/s0:StudentDetails/Marks/text()"" />
      </Marks>
      <grade>
        <xsl:value-of select=""InputMessagePart_0/s0:StudentDetails/Grade/text()"" />
      </grade>
      <Subject>
        <xsl:value-of select=""InputMessagePart_0/s0:StudentDetails/Subject/text()"" />
      </Subject>
      <xsl:if test=""InputMessagePart_1/s1:getstudentInformationResponse/s1:StoredProcedureResultSet0/s3:StoredProcedureResultSet0/s3:Fname"">
        <Fname>
          <xsl:value-of select=""InputMessagePart_1/s1:getstudentInformationResponse/s1:StoredProcedureResultSet0/s3:StoredProcedureResultSet0/s3:Fname/text()"" />
        </Fname>
      </xsl:if>
      <xsl:if test=""InputMessagePart_1/s1:getstudentInformationResponse/s1:StoredProcedureResultSet0/s3:StoredProcedureResultSet0/s3:Lname"">
        <Lname>
          <xsl:value-of select=""InputMessagePart_1/s1:getstudentInformationResponse/s1:StoredProcedureResultSet0/s3:StoredProcedureResultSet0/s3:Lname/text()"" />
        </Lname>
      </xsl:if>
      <xsl:if test=""InputMessagePart_1/s1:getstudentInformationResponse/s1:StoredProcedureResultSet0/s3:StoredProcedureResultSet0/s3:CLASS"">
        <Class>
          <xsl:value-of select=""InputMessagePart_1/s1:getstudentInformationResponse/s1:StoredProcedureResultSet0/s3:StoredProcedureResultSet0/s3:CLASS/text()"" />
        </Class>
      </xsl:if>
    </ns0:Output>
  </xsl:template>
</xsl:stylesheet>";
        
        private const int _useXSLTransform = 0;
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Demo_student_application.InputSchema";
        
        private const global::Demo_student_application.InputSchema _srcSchemaTypeReference0 = null;
        
        private const string _strSrcSchemasList1 = @"Demo_student_application.TypedProcedure_dbo+getstudentInformationResponse";
        
        private const global::Demo_student_application.TypedProcedure_dbo.getstudentInformationResponse _srcSchemaTypeReference1 = null;
        
        private const string _strTrgSchemasList0 = @"Demo_student_application.OutPutSchema";
        
        private const global::Demo_student_application.OutPutSchema _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override int UseXSLTransform {
            get {
                return _useXSLTransform;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [2];
                _SrcSchemas[0] = @"Demo_student_application.InputSchema";
                _SrcSchemas[1] = @"Demo_student_application.TypedProcedure_dbo+getstudentInformationResponse";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Demo_student_application.OutPutSchema";
                return _TrgSchemas;
            }
        }
    }
}
