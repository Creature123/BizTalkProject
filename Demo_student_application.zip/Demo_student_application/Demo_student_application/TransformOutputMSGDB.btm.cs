namespace Demo_student_application {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demo_student_application.OutPutSchema", typeof(global::Demo_student_application.OutPutSchema))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demo_student_application.TypedProcedure_dbo1+setstudentExaminationData", typeof(global::Demo_student_application.TypedProcedure_dbo1.setstudentExaminationData))]
    public sealed class TransformOutputMSGDB : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0"" version=""1.0"" xmlns:s0=""http://Demo_student_application.OutPutSchema"" xmlns:ns0=""http://schemas.microsoft.com/Sql/2008/05/TypedProcedures/dbo"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:Output"" />
  </xsl:template>
  <xsl:template match=""/s0:Output"">
    <ns0:setstudentExaminationData>
      <ns0:RegistrationID>
        <xsl:value-of select=""RegistrationID/text()"" />
      </ns0:RegistrationID>
      <ns0:Marks>
        <xsl:value-of select=""Marks/text()"" />
      </ns0:Marks>
      <ns0:grade>
        <xsl:value-of select=""grade/text()"" />
      </ns0:grade>
      <ns0:Subject>
        <xsl:value-of select=""Subject/text()"" />
      </ns0:Subject>
      <ns0:Fname>
        <xsl:value-of select=""Fname/text()"" />
      </ns0:Fname>
      <ns0:Lname>
        <xsl:value-of select=""Lname/text()"" />
      </ns0:Lname>
      <ns0:Class>
        <xsl:value-of select=""Class/text()"" />
      </ns0:Class>
    </ns0:setstudentExaminationData>
  </xsl:template>
</xsl:stylesheet>";
        
        private const int _useXSLTransform = 0;
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Demo_student_application.OutPutSchema";
        
        private const global::Demo_student_application.OutPutSchema _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Demo_student_application.TypedProcedure_dbo1+setstudentExaminationData";
        
        private const global::Demo_student_application.TypedProcedure_dbo1.setstudentExaminationData _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override int UseXSLTransform {
            get {
                return _useXSLTransform;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Demo_student_application.OutPutSchema";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Demo_student_application.TypedProcedure_dbo1+setstudentExaminationData";
                return _TrgSchemas;
            }
        }
    }
}
