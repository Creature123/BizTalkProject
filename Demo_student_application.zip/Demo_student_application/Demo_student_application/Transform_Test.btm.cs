namespace Demo_student_application {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demo_student_application.InputSchema", typeof(global::Demo_student_application.InputSchema))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demo_student_application.TypedProcedure_dbo+getstudentInformation", typeof(global::Demo_student_application.TypedProcedure_dbo.getstudentInformation))]
    public sealed class Transform_Test : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0"" version=""1.0"" xmlns:s0=""http://Demo_student_application.InputSchema"" xmlns:ns3=""http://schemas.microsoft.com/Sql/2008/05/ProceduresResultSets/dbo/getstudentInformation"" xmlns:ns0=""http://schemas.microsoft.com/Sql/2008/05/TypedProcedures/dbo"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:StudentDetails"" />
  </xsl:template>
  <xsl:template match=""/s0:StudentDetails"">
    <ns0:getstudentInformation>
      <ns0:Requestid>
        <xsl:value-of select=""ReqID/text()"" />
      </ns0:Requestid>
    </ns0:getstudentInformation>
  </xsl:template>
</xsl:stylesheet>";
        
        private const int _useXSLTransform = 0;
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Demo_student_application.InputSchema";
        
        private const global::Demo_student_application.InputSchema _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Demo_student_application.TypedProcedure_dbo+getstudentInformation";
        
        private const global::Demo_student_application.TypedProcedure_dbo.getstudentInformation _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override int UseXSLTransform {
            get {
                return _useXSLTransform;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Demo_student_application.InputSchema";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Demo_student_application.TypedProcedure_dbo+getstudentInformation";
                return _TrgSchemas;
            }
        }
    }
}
